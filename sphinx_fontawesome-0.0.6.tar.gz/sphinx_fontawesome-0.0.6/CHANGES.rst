0.0.5
=====

- correction setup.py not call sphinx_fontawesome

0.0.4
=====

- correction REQUIREMENT

0.0.3
=====

- add newline after prolog
- update list icons
- update version css in README

0.0.2
=====

- css for list of task in README
- manage alias

0.0.1
=====

initialize extension
