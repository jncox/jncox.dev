# This will be included as python in the reference page
print(1)
print(1)
print(1)
print(1)
